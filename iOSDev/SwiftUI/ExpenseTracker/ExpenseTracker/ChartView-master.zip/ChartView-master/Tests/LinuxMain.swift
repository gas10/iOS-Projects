import XCTest

import SwiftUIChartsTests

var tests = [XCTestCaseEntry]()
tests += SwiftUIChartsTests.allTests()
XCTMain(tests)
