---
name: v2 ticket
about: Create tasks for the upcoming new version
title: ''
labels: v2
assignees: ''

---
# v2 ticket

## Ticket description:
